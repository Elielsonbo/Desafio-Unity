using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Carrodepapelao : MonoBehaviour
{
    private Transform transformpapelao;
    private Rigidbody rigidbodypapelao;
    private Vector3 velocidade;
    public MeshCollider Pista;
   
    // Start is called before the first frame update
    void Start()
    {
        rigidbodypapelao = GetComponent<Rigidbody>();
        velocidade = new Vector3(0, 0, 0.2f);
    }

    // Update is called once per frame
    void Update()
    {
        rigidbodypapelao.AddForce(velocidade, ForceMode.VelocityChange);
    }
}
